def set_angle(index,angle):
	import time
	import RPi.GPIO as GPIO
	import os
	from smbus import SMBus
	XRservo=SMBus(1)

	max_angle=180
	min_angle=0

	if angle>max_angle:
		angle=max_angle
	elif angle<min_angle:
		angle=min_angle

 	XRservo.XiaoRGEEK_SetServo(index,angle)
	


