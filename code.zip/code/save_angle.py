import time
import RPi.GPIO as GPIO
import os
from smbus import SMBus
XRservo=SMBus(1)


XRservo.XiaoRGEEK_SaveServo()



