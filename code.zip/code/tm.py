from motol_motion import *
	
left_motol(1)
time.sleep(0.5)
stop()
time.sleep(0.5)
right_motol(1)
time.sleep(0.5)
stop()
	
	


