﻿#include <iostream>
#include <opencv2\imgproc.hpp>	
#include <opencv2\calib3d.hpp>
#include <opencv2\highgui.hpp>
#include <Kinect.h>	
#include<codecvt>
#include<winsock.h>
#include<string>
#include <math.h>

#pragma comment(lib,"ws2_32.lib")
#include <pthread.h>  
#include <windows.h>//使用Sleep的头
using   namespace   std;
using   namespace   cv;
int g_number = 0;
#define TURN_ERR 100
int ss(string x);
void initialization();
void    draw(Mat& img, Joint& r_1, Joint& r_2, ICoordinateMapper* myMapper);

SOCKET s_server;

HandState leftHandState = HandState_Unknown;    // 手形
HandState rightHandState = HandState_Unknown;
Point lefthand, righthand;

boolean startmark = FALSE;
boolean quitmark = FALSE;

void* counter1(void* args) //socket
{
    int send_len = 0;
    SOCKADDR_IN server_addr;
    initialization();
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.S_un.S_addr = inet_addr("192.168.1.1");
    server_addr.sin_port = htons(2222);
    s_server = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(s_server, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
        cout << "服务器连接失败！" << endl;
        //return 0;
        WSACleanup();
    }
    else {
        cout << "服务器连接成功！" << endl;
    }
    while (!startmark);
    Sleep(100);
    while (!quitmark) 
    {
        int right_y_prev = righthand.y;
        int right_x_prev = righthand.x;
        Sleep(10);
        if (leftHandState == HandState_Closed) // motor ctrl
        {
            if (rightHandState == HandState_Closed)  //turn and go
            {
                if (abs(lefthand.y - righthand.y) <= TURN_ERR) {//差不多高 go
                    ss("030000");
                }
                else if (lefthand.y - righthand.y < -TURN_ERR) {//左手高 turn right
                    ss("020000");
                }
                else if (lefthand.y - righthand.y > TURN_ERR) {//右手高 turn left
                    ss("010000");
                }
            }
            else if (rightHandState == HandState_Open)  // turn and back
            {
                
                if (abs(lefthand.y - righthand.y) <= TURN_ERR) {//差不多高 go
                    ss("040000");
                }
                else if (lefthand.y - righthand.y < -TURN_ERR) {//左手高 turn right
                    ss("020000");
                }
                else if (lefthand.y - righthand.y > TURN_ERR) {//右手高 turn left
                    ss("010000");
                }
                
            }
            else ss("000000");
        }
        else if (leftHandState == HandState_Lasso)  // arm
        {
            //ss("000000");
            if (rightHandState == HandState_Closed)
                ss("140000");
            else if(rightHandState == HandState_Open)
                ss("240000");
            /*4*/
            Sleep(10);
            if (rightHandState == HandState_Lasso) // turn 0x03
            {
                int err_y = (lefthand.y - righthand.y)/2;
                if (err_y < 0) {//左手高 turn right
                    ss(to_string(230000+abs(err_y)));
                }
                else if (err_y > 0) {//右手高 turn left
                    ss(to_string(130000 + abs(err_y)));
                }
            }
            else if (rightHandState == HandState_Open || rightHandState == HandState_Closed) // up down 1 2
            {
                
                int err_ry = righthand.y - right_y_prev;
                int err_rx = righthand.x - right_x_prev;

                err_ry = (abs(err_ry) < 12) ? abs(err_ry) : 12;  //limit
                err_ry = (err_ry > 1) ? err_ry : 0;
                err_ry = int(err_ry / 2);

                if (righthand.y - right_y_prev > 1) // up
                {
                    ss(to_string(210000 + err_ry));
                    printf("21:%d\n",err_ry);
                }
                else if (righthand.y - right_y_prev < -1) //down
                {
                    ss(to_string(110000 + err_ry));
                    printf("11:%d\n", err_ry);
                }

                if (righthand.x - right_x_prev > 2) // right
                {
                    ss("020000");    
                }
                else if (righthand.x - right_x_prev < -2) //left
                {
                    ss("010000");  
                }

            }
        }
        else if (leftHandState == HandState_Open)
        {
            ss("000000");
        }
        else
        {
            
        }

    }
    ss("000000");
    Sleep(10);
    ss("qq");
    Sleep(100);
    closesocket(s_server);
    WSACleanup();
	return 0;
}

void* counter2(void* args) {
        startmark = TRUE;

        IKinectSensor* mySensor = nullptr;
        GetDefaultKinectSensor(&mySensor);
        mySensor->Open();

        IColorFrameSource* myColorSource = nullptr;
        mySensor->get_ColorFrameSource(&myColorSource);

        IColorFrameReader* myColorReader = nullptr;
        myColorSource->OpenReader(&myColorReader);

        int colorHeight = 0, colorWidth = 0;
        IFrameDescription* myDescription = nullptr;
        myColorSource->get_FrameDescription(&myDescription);
        myDescription->get_Height(&colorHeight);
        myDescription->get_Width(&colorWidth);

        IColorFrame* myColorFrame = nullptr;
        Mat original(colorHeight, colorWidth, CV_8UC4, Scalar(0,0,0,0));
        cout << colorHeight << ";" << colorWidth << endl;
        //**********************以上为ColorFrame的读取前准备**************************

        IBodyFrameSource* myBodySource = nullptr;
        mySensor->get_BodyFrameSource(&myBodySource);

        IBodyFrameReader* myBodyReader = nullptr;
        myBodySource->OpenReader(&myBodyReader);

        int myBodyCount = 0;
        myBodySource->get_BodyCount(&myBodyCount);

        IBodyFrame* myBodyFrame = nullptr;

        ICoordinateMapper* myMapper = nullptr;
        mySensor->get_CoordinateMapper(&myMapper);

        ShellExecute(NULL, L"open", L"http://192.168.1.1:8080/javascript_simple.html",NULL, NULL, SW_SHOWNORMAL);
        //**********************以上为BodyFrame以及Mapper的准备***********************
        while (1)
        {
			//是否需要彩色图像
            //while (myColorReader->AcquireLatestFrame(&myColorFrame) != S_OK);
            //myColorFrame->CopyConvertedFrameDataToArray(colorHeight * colorWidth * 4, original.data, ColorImageFormat_Bgra);
            Mat copy = original.clone();        //读取彩色图像并输出到矩阵

            while (myBodyReader->AcquireLatestFrame(&myBodyFrame) != S_OK); //读取身体图像
            IBody** myBodyArr = new IBody * [myBodyCount];       //为存身体数据的数组做准备
            for (int i = 0; i < myBodyCount; i++)
                myBodyArr[i] = nullptr;

            if (myBodyFrame->GetAndRefreshBodyData(myBodyCount, myBodyArr) == S_OK)     //把身体数据输入数组
                for (int i = 0; i < myBodyCount; i++)
                {
                    BOOLEAN     result = false;
                    if (myBodyArr[i]->get_IsTracked(&result) == S_OK && result) //先判断是否侦测到
                    {
                        Joint   myJointArr[JointType_Count];

                        myBodyArr[i]->get_HandLeftState(&leftHandState);
                        myBodyArr[i]->get_HandRightState(&rightHandState);
                        if (myBodyArr[i]->GetJoints(JointType_Count, myJointArr) == S_OK)   //如果侦测到就把关节数据输入到数组并画图
                        {
                            draw(copy, myJointArr[JointType_Head], myJointArr[JointType_Neck], myMapper);
                            draw(copy, myJointArr[JointType_Neck], myJointArr[JointType_SpineShoulder], myMapper);

                            draw(copy, myJointArr[JointType_SpineShoulder], myJointArr[JointType_ShoulderLeft], myMapper);
                            draw(copy, myJointArr[JointType_SpineShoulder], myJointArr[JointType_SpineMid], myMapper);
                            draw(copy, myJointArr[JointType_SpineShoulder], myJointArr[JointType_ShoulderRight], myMapper);

                            draw(copy, myJointArr[JointType_ShoulderLeft], myJointArr[JointType_ElbowLeft], myMapper);
                            draw(copy, myJointArr[JointType_SpineMid], myJointArr[JointType_SpineBase], myMapper);
                            draw(copy, myJointArr[JointType_ShoulderRight], myJointArr[JointType_ElbowRight], myMapper);

                            draw(copy, myJointArr[JointType_ElbowLeft], myJointArr[JointType_WristLeft], myMapper);
                            draw(copy, myJointArr[JointType_SpineBase], myJointArr[JointType_HipLeft], myMapper);
                            draw(copy, myJointArr[JointType_SpineBase], myJointArr[JointType_HipRight], myMapper);
                            draw(copy, myJointArr[JointType_ElbowRight], myJointArr[JointType_WristRight], myMapper);

                            draw(copy, myJointArr[JointType_WristLeft], myJointArr[JointType_ThumbLeft], myMapper);
                            draw(copy, myJointArr[JointType_WristLeft], myJointArr[JointType_HandLeft], myMapper);
                            draw(copy, myJointArr[JointType_HipLeft], myJointArr[JointType_KneeLeft], myMapper);
                            draw(copy, myJointArr[JointType_HipRight], myJointArr[JointType_KneeRight], myMapper);
                            draw(copy, myJointArr[JointType_WristRight], myJointArr[JointType_ThumbRight], myMapper);
                            draw(copy, myJointArr[JointType_WristRight], myJointArr[JointType_HandRight], myMapper);

                            draw(copy, myJointArr[JointType_HandLeft], myJointArr[JointType_HandTipLeft], myMapper);
                            draw(copy, myJointArr[JointType_KneeLeft], myJointArr[JointType_FootLeft], myMapper);
                            draw(copy, myJointArr[JointType_KneeRight], myJointArr[JointType_FootRight], myMapper);
                            draw(copy, myJointArr[JointType_HandRight], myJointArr[JointType_HandTipRight], myMapper);
                            ColorSpacePoint t_point;
                            
                            myMapper->MapCameraPointToColorSpace(myJointArr[JointType_HandLeft].Position, &t_point);
                            lefthand.x = t_point.X;
                            lefthand.y = t_point.Y;
                            myMapper->MapCameraPointToColorSpace(myJointArr[JointType_HandRight].Position, &t_point);
                            righthand.x = t_point.X;
                            righthand.y = t_point.Y;
                            //  cout << righthand.x << "," << righthand.y << endl;  // 坐标系测试：坐标原点是视频左上角，x是到竖轴的距离，y是到横轴的距离
                            int linethickness = 4;
                            int circleradius = 50;
                            if (leftHandState == HandState_Open) {
                                circle(copy, lefthand, circleradius, Vec3b(0, 255, 0), linethickness);//green = open
                            }
                            else if (leftHandState == HandState_Closed) {
                                circle(copy, lefthand, circleradius, Vec3b(0, 0, 255), linethickness);// red = closed
                            }
                            else if (leftHandState == HandState_Lasso) {
                                circle(copy, lefthand, circleradius, Vec3b(255, 0, 0), linethickness);// blue = lasso 
                            }
							
                            if (rightHandState == HandState_Open)
                                circle(copy, righthand, circleradius, Vec3b(0, 255, 0), linethickness);//green = open
                            else if (rightHandState == HandState_Closed)
                                circle(copy, righthand, circleradius, Vec3b(0, 0, 255), linethickness);// red = closed
                            else if (rightHandState == HandState_Lasso)
                                circle(copy, righthand, circleradius, Vec3b(255, 0, 0), linethickness);// blue = lasso
                        }
                    }
                }
            delete[]myBodyArr;
            myBodyFrame->Release();
            //myColorFrame->Release();
            namedWindow("TEST",0);
            cv::resizeWindow("TEST",1024,576);
            cv::imshow("TEST", copy);
            if (waitKey(30) == VK_ESCAPE)
            {
                quitmark = TRUE;
                break;
            }
        }

        myMapper->Release();

        myDescription->Release();
        myColorReader->Release();
        myColorSource->Release();

        myBodyReader->Release();
        myBodySource->Release();
        mySensor->Close();
        mySensor->Release();
        
        return  0;
}

int main() {
	pthread_t t1;
	pthread_t t2;

	pthread_create(&t1, NULL, counter1, NULL);
	pthread_create(&t2, NULL, counter2, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    return 0;
}

void    draw(Mat& img, Joint& r_1, Joint& r_2, ICoordinateMapper* myMapper)
{
    //用两个关节点来做线段的两端，并且进行状态过滤
    if (r_1.TrackingState == TrackingState_Tracked && r_2.TrackingState == TrackingState_Tracked)
    {
        ColorSpacePoint t_point;    //要把关节点用的摄像机坐标下的点转换成彩色空间的点
        Point   p_1, p_2;
        myMapper->MapCameraPointToColorSpace(r_1.Position, &t_point);
        p_1.x = t_point.X;
        p_1.y = t_point.Y;
        myMapper->MapCameraPointToColorSpace(r_2.Position, &t_point);
        p_2.x = t_point.X;
        p_2.y = t_point.Y;

        line(img, p_1, p_2, Vec3b(0, 255, 0), 2);
        circle(img, p_1, 4, Vec3b(0, 255, 0), -1);
        circle(img, p_2, 4, Vec3b(0, 255, 0), -1);
    }
}

void initialization() {
    //初始化套接字库
    WORD w_req = MAKEWORD(2, 2);//版本号
    WSADATA wsadata;
    int err;
    err = WSAStartup(w_req, &wsadata);
    if (err != 0) {
        cout << "初始化套接字库失败！" << endl;
    }
    else {
        cout << "初始化套接字库成功！" << endl;
    }
    //检测版本号
    if (LOBYTE(wsadata.wVersion) != 2 || HIBYTE(wsadata.wHighVersion) != 2) {
        cout << "套接字库版本号不符！" << endl;
        WSACleanup();
    }
    else {
        cout << "套接字库版本正确！" << endl;
    }
    //填充服务端地址信息
}

int ss(string x) {
    int y;
    y = send(s_server, x.c_str(), strlen(x.c_str()), 0);
    return y;
}