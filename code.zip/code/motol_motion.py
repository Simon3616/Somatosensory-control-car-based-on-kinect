import RPi.GPIO as GPIO
from smbus import SMBus
XRservo=SMBus(1)
def set_angle(index,angle):
 	XRservo.XiaoRGEEK_SetServo(index,angle)

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

ENA=13
ENB=20
IN1=19
IN2=16
IN3=21
IN4=26
def motion_initial():
	GPIO.setup(ENA,GPIO.OUT,initial=GPIO.LOW)
	GPIO.setup(ENB,GPIO.OUT,initial=GPIO.LOW)
	GPIO.setup(IN1,GPIO.OUT,initial=GPIO.LOW)
	GPIO.setup(IN2,GPIO.OUT,initial=GPIO.LOW)
	GPIO.setup(IN3,GPIO.OUT,initial=GPIO.LOW)
	GPIO.setup(IN4,GPIO.OUT,initial=GPIO.LOW)
	
motion_initial()

def gogo():
	##print("all go")
	GPIO.output(ENA,True)
	GPIO.output(IN1,True)
	GPIO.output(IN2,False)
	
	GPIO.output(ENB,True)
	GPIO.output(IN3,True)
	GPIO.output(IN4,False)
	
def back():
	##print("all back")
	GPIO.output(ENA,True)
	GPIO.output(IN1,False)
	GPIO.output(IN2,True)
	
	GPIO.output(ENB,True)
	GPIO.output(IN3,False)
	GPIO.output(IN4,True)
	
def stop():
	##print("all stop")
	GPIO.output(ENA,False)
	GPIO.output(IN1,False)
	GPIO.output(IN2,False)
	
	GPIO.output(ENB,False)
	GPIO.output(IN3,False)
	GPIO.output(IN4,False)

def left_motol(x): ##0:stop   1:forward   -1:back
	GPIO.output(ENA,x)
	if x==0:
		GPIO.output(IN1,0)
		GPIO.output(IN2,0)
		##print("left stop")
	elif x==1:
		GPIO.output(IN1,1)
		GPIO.output(IN2,0)
		##print("left go")
	else:
		GPIO.output(IN1,0)
		GPIO.output(IN2,1)
		##print("left back")

def right_motol(x): ##0:stop   1:forward   -1:back
	GPIO.output(ENB,x)
	if x==0:
		GPIO.output(IN3,0)
		GPIO.output(IN4,0)
		##print("right stop")
	elif x==1:
		GPIO.output(IN3,1)
		GPIO.output(IN4,0)
		##print("right go")
	else:
		GPIO.output(IN3,0)
		GPIO.output(IN4,1)
		##print("right back")
	

	
	


