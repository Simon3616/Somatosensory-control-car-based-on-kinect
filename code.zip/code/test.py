from set_angle import set_angle as ss

ss(0x01,120)

	


