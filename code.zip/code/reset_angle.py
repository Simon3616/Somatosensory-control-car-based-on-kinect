import time
import RPi.GPIO as GPIO
import os
from smbus import SMBus
XRservo=SMBus(1)
XRservo.XiaoRGEEK_ReSetServo()
def reset_angle():
    XRservo.XiaoRGEEK_ReSetServo()
