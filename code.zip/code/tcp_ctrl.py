# encoding: utf-8
import chardet
from motol_motion import *
import socket
import time
import os
print("Sever Started.")
#套接字接口
mySocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#设置IP和端口
host = '192.168.1.1'
port = 2222
#bind绑定该端口
mySocket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
mySocket.bind((host, port))
mySocket.listen(10)
motion_initial()
angle=[0,130,175,90,100,0,0,90,0] ## init
XRservo.XiaoRGEEK_ReSetServo() ##reset angle
os.system("cd ~/work/mjpg-streamer-experimental-xr")
try:
	os.system("./mjpg_streamer -i \"./input_raspicam.so\" -o \"./output_http.so -w ./www\"")
except:
	print("video was opened or failed")
while True:
    #接收客户端连接
	print("Wait For Connect....")
   	client, address = mySocket.accept()
	print("Connected.")
	print("IP is %s" % address[0])
	print("port is %d\n" % address[1]) 
	while True:
		#读取消息
		msg = client.recv(1024)
		stop()
		print(msg.decode('EUC-JP'))
		#把接收到的数据进行解码
		##print(msg.encode("utf-8"))
		msg1=msg[0:2]
		##print(chardet.detect(msg))
		try: 								##xx
			msg2=int(msg[2:6])				##xxxx
		except:
			msg2=0		
		#print("message received")
		if msg == "hello":
			print("im server")
		elif msg== "1234":
			print("re1234")
		elif msg1 == b"00":			##00:stop
			right_motol(0)
			left_motol(0)
		elif msg1 == b"01":			##01:left	  
			left_motol(-1)
			right_motol(1)
			time.sleep(0.02)
		elif msg1 == b"02":			##02:right	
			right_motol(-1)
			left_motol(1)
			time.sleep(0.02)
		elif msg1 == b"03":			##03:go		
			right_motol(1)
			left_motol(1)
			time.sleep(0.02)
			angle[7]=180
			angle[8]=25
			set_angle(0x07,angle[7])
			set_angle(0x08,angle[8])
		elif msg1 == b"04":			##04:back	
			right_motol(-1)
			left_motol(-1)
			time.sleep(0.02)
			angle[7]=0
			angle[8]=25
			set_angle(0x07,angle[7])
			set_angle(0x08,angle[8])
		elif msg1 == b"10":
			reset_angle()
		elif msg1 == b"11":			##up(inc) 1&2			1:up(130) low(45)  2: up(175) low(135) 
			if (angle[2]==175):## move 1
				if (angle[1]+msg2<130):
					angle[1]=angle[1]+msg2
				else:
					angle[1]=130
				angle[8]=10+40*(angle[1]-45)/85
			else:
				if (angle[2]+msg2<175):
					angle[2]=angle[2]+msg2
				else:
					angle[2]=175
				angle[8]=(angle[2]-135)/4
			angle[7]=180
			set_angle(0x08,angle[8])
			set_angle(0x07,angle[7])
			set_angle(0x01,angle[1])
			set_angle(0x02,angle[2])
		elif msg1 == b"21":			##down(dec) 1&2
			if (angle[1]==45):## move 2
				if (angle[2]-msg2>135):
					angle[2]=angle[2]-msg2
				else:
					angle[2]=135
				angle[8]=(angle[2]-135)/4
			else:
				if (angle[1]-msg2>45):
					angle[1]=angle[1]-msg2
				else:
					angle[1]=45
				angle[8]=10+40*(angle[1]-45)/85
			angle[7]=180
			set_angle(0x08,angle[8])
			set_angle(0x07,angle[7])
			set_angle(0x01,angle[1])
			set_angle(0x02,angle[2])
		elif msg1 == b"13":			##left(dec) 3
			if (90-msg2)>=0:
				angle[3]=90-msg2
			else:
				angle[3]=0
			set_angle(0x03,angle[3])
		elif msg1 == b"23":			##right(inc) 3
			if (90+msg2)<=180:
				angle[3]=90+msg2
			else:
				angle[3]=180
			set_angle(0x03,angle[3])
		elif msg1 == b"14":			##he(inc 150) 4				100~150
			angle[4] = 150
			set_angle(0x04,angle[4])
		elif msg1 == b"24":			##zhang(dec 100) 4
			angle[4] = 100
			set_angle(0x04,angle[4])
		elif msg == b"qq":			
			client.close()
			mySocket.close()
			print("end\n")
			exit()
